package se.atg.service.harrykart.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HarryKartApp {
    public static void main(String ... args) {
        SpringApplication.run(HarryKartApp.class, args);
    }
}
