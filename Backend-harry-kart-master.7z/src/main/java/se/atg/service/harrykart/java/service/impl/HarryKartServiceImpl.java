package se.atg.service.harrykart.java.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import se.atg.service.harrykart.java.dto.HarryKart;
import se.atg.service.harrykart.java.dto.HorseRank;
import se.atg.service.harrykart.java.service.HarryKartService;

@Service
public class HarryKartServiceImpl implements HarryKartService {

	public static final double TRACKLENGTH = 1000.0;

	@Override
	public List<HorseRank> getHorseRank(HarryKart harryKart) {
		List<HorseRank> positionList = new ArrayList<>();

		getRankList(harryKart, positionList);

		Collections.sort(positionList, Comparator.comparing(HorseRank::getTime));
		positionList.removeIf(rank -> rank.getTime() >= Double.MAX_VALUE);

		getFinalPosition(positionList);
		List<HorseRank> finalPosition = positionList.stream().map(p->new HorseRank(p.getPosition(), p.getHorseName())).collect(Collectors.toList());
		return finalPosition.stream().filter(rank -> rank.getPosition() <= 3).collect(Collectors.toList());
	}

	private void getFinalPosition(List<HorseRank> positionList) {
		int finalPlacement = 1;
		positionList.get(0).setPosition(finalPlacement);
		for (int positionIndex = 1; positionIndex < positionList.size(); positionIndex++) {
			if (positionList.get(positionIndex).getTime() == positionList.get(positionIndex - 1).getTime()) {
				positionList.get(positionIndex).setPosition(finalPlacement);
			} else {
				positionList.get(positionIndex).setPosition(++finalPlacement);
			}
		}
	}

	private void getRankList(HarryKart harryKart, List<HorseRank> positionList) {
		harryKart.getStartList().forEach(participant -> {
			HorseRank rank = new HorseRank(0, participant.getName(), TRACKLENGTH / participant.getBaseSpeed());
			harryKart.getPowerUps()
					.stream()
					.forEach(loop -> loop.getLanes().stream().filter(lane -> lane.getNumber() == participant.getLane()).forEach(lane -> {
						int loopSpeed = participant.getBaseSpeed() + lane.getPowerValue();
						if (loopSpeed <= 0) {
							rank.setTime(rank.getTime() + Double.MAX_VALUE);
						} else {
							participant.setBaseSpeed(participant.getBaseSpeed() + lane.getPowerValue());
							rank.setTime(rank.getTime() + (TRACKLENGTH / participant.getBaseSpeed()));
						}
					}));
			positionList.add(rank);
		});
	}
}
