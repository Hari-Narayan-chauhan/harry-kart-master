package se.atg.service.harrykart.java.exception;

public class HarryKartException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public HarryKartException(String message) {
		super(message);
	}

}
