package se.atg.service.harrykart.kotlin

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class HarryKartApp

fun main(args: Array<String>) {
    runApplication<HarryKartApp>(*args)
}
